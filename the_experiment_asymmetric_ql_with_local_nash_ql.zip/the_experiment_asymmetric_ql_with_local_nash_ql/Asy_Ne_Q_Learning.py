from utilities.static_utilities_q_table import *
from action_selection.epsilon_greedy import epsilon_greedy
import pandas as pd


class AsyNeQLearning:
    def __init__(self, Asy_Ne_q_learning_setting, state_names_list, action_names_list):
        """Initialization"""
        print('Asy_Ne_Q_Learning...')
        self.paras = Asy_Ne_q_learning_setting['paras']
        self.action_selection_model = Asy_Ne_q_learning_setting['action_selection']
        self.state_num = len(state_names_list)
        self.state_names = state_names_list
        self.action_names = action_names_list
        # initialize q table
        self.Asy_Ne_ql_q_table = self.__init_q_table_from_states_and_actions(state_name_list=state_names_list,
                                                                             action_name_list=action_names_list)

    def __init_q_table_from_states_and_actions(self, state_name_list, action_name_list):
        """create q-table 仅完成初始化，通过添加index使空间动态增长"""
        arrays = [[0] * 1] * self.state_num  # looks like ep. arrays1 = [[0], [0]]
        idx = pd.MultiIndex.from_arrays(arrays, names=state_name_list)
        q_table = pd.DataFrame(0, index=idx, columns=action_name_list)
        return q_table

    def select_action_eps_greedy(self, state):
        """action  selection epsilon greedy算法"""
        self.__check_state_exist(state)
        eps = self.paras['epsilon']
        return epsilon_greedy(epsilon=eps, state=state, q_table=self.Asy_Ne_ql_q_table, all_actions=self.action_names)

    def get_q_value_by(self, state, action):
        """根据state和action读取Q值"""
        self.__check_state_exist(state)
        return self.Asy_Ne_ql_q_table.loc[state, action]

    def get_action_selection_model(self):
        """获得该Agent的动作选择模型"""
        return self.action_selection_model['model']

    def __update_Asy_NE_ql_q_table_by(self, state, action, q):
        """ update q table with state,action,q"""
        self.Asy_Ne_ql_q_table.loc[state, action] = q

    def __check_state_exist(self, state):
        """检查state是否存在q table中"""
        Asy_Ne_q_table_idx = self.Asy_Ne_ql_q_table.index
        if Asy_Ne_q_table_idx.isin([state]).any():
            pass
        else:
            idx = pd.MultiIndex.from_tuples([state], names=self.state_names)
            df = pd.DataFrame(0, index=idx, columns=self.action_names)
            self.Asy_Ne_ql_q_table = pd.concat([self.Asy_Ne_ql_q_table, df])  # 将df合并

    def update_Asy_NE_q_learning_table(self, current_state, action, reward, game_theory_value):
        """更新Q表，只考虑本地信息"""
        self.__check_state_exist(current_state)
        # 获取参数
        alpha = self.paras['alpha']
        gamma = self.paras['gamma']
        pre_q = self.Asy_Ne_ql_q_table.loc[current_state, action]
        q_new = q_table_q_value(alpha=alpha, gamma=gamma, reward=reward, pre_q=pre_q,
                                game_theory_value=game_theory_value)
        self.__update_Asy_NE_ql_q_table_by(state=current_state, action=action, q=q_new)

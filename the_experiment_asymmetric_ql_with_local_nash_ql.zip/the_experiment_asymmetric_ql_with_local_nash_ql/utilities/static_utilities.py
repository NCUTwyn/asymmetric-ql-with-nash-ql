import yaml
from Asy_NE_agent import AsyNeQlAgent


def get_settings_from_yaml(yaml_file):
    """Read config information from yaml file"""
    yaml_data = read_yaml(yaml_file)[0]
    environment_setting = yaml_data['environment_settings']
    agents_setting = yaml_data['agents_settings']
    constants_setting = yaml_data['constants_settings']
    return environment_setting, agents_setting, constants_setting


def initialize_agents_by(agents_setting):
    """Initialize all asymmetric ql agents according to asymmetric ql agents setting"""
    agents = {}
    for key, val in agents_setting.items():
        agents[key] = AsyNeQlAgent(agents_setting=val)
    return agents


def read_yaml(yaml_file):
    """to read a yaml file"""
    with open(yaml_file, 'rb') as f:
        all_data = list(yaml.safe_load_all(f))
    return all_data

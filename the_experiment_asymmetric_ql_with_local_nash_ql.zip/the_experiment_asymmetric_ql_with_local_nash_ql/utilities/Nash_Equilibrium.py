import pandas as pd
from utilities.lemkeHowson import lemkeHowson
from utilities import matrix
from utilities import lemkeHowson
import numpy as np


def initialize_NE_payoff_table(agents_setting):
    NE_agents_payoff_table_dic = {}
    NE_agents_list = []
    for key, val in agents_setting.items():
        if agents_setting[key]['identity'] == 'Leader':
            NE_agents_list.append(key)
        else:
            pass
    loc = agents_setting[NE_agents_list[0]]['action']['names']
    col = agents_setting[NE_agents_list[1]]['action']['names']
    for key, val in agents_setting.items():
        NE_agents_payoff_table_dic[key] = pd.DataFrame(0, index=loc, columns=col)
    return NE_agents_payoff_table_dic, loc, col, NE_agents_list


def get_leaders_NE_values_by(NE_agents_list, NE_payoff_table_dic, loc, col):
    nash_values_table_list = []
    for key, val in NE_payoff_table_dic.items():
        nash_values_table_list.append(NE_payoff_table_dic[key])
    m0, m1 = construct_payoff_table(nash_values_table_list, loc=loc, col=col)
    nash_q_values = calculate_nash_ql_values(m0=m0, m1=m1)
    nash_q_values_dic = {}
    i = 0
    for name_id in NE_agents_list:
        nash_q_values_dic[name_id] = nash_q_values[i]
        i += 1

    return nash_q_values_dic


def construct_payoff_table(nash_values_table_list, loc, col):
    m0 = matrix.Matrix(nash_values_table_list[0].shape[0], nash_values_table_list[0].shape[1])
    m1 = matrix.Matrix(nash_values_table_list[1].shape[1], nash_values_table_list[1].shape[0])
    for i in range(nash_values_table_list[0].shape[0]):
        for j in range(nash_values_table_list[1].shape[1]):
            m0.setItem(i+1, j+1, nash_values_table_list[0][loc[i]][col[j]])
            m1.setItem(i+1, j+1, nash_values_table_list[1][col[i]][loc[j]])
    return m0, m1


def calculate_nash_ql_values(m0, m1):
    # m0 and m1 are payoff tables of agent0 and agent1
    (m0, m1) = (m0, m1)
    probprob = lemkeHowson.lemkeHowson(m1=m0, m2=m1)
    prob0 = np.array(probprob[0])
    prob1 = np.array(probprob[1])
    prob0 = np.matrix(prob0)
    prob1 = np.matrix(prob1).reshape((-1, 1))
    # calculate the nash values
    m_m0 = []
    m_m1 = []
    for i in range(m0.getNumRows()):
        for j in range(m0.getNumCols()):
            m_m0.append(m0.getItem(i + 1, j + 1))
    for i in range(m1.getNumRows()):
        for j in range(m1.getNumCols()):
            m_m1.append(m1.getItem(i + 1, j + 1))
    m_m0 = np.matrix(m_m0).reshape((m0.getNumRows(), m0.getNumCols()))
    m_m1 = np.matrix(m_m1).reshape((m1.getNumRows(), m1.getNumCols()))
    m_nash0 = prob0 * m_m0 * prob1
    m_nash1 = prob0 * m_m1 * prob1
    nash0 = m_nash0[0, 0].nom() / m_nash0[0, 0].denom()
    nash1 = m_nash1[0, 0].nom() / m_nash1[0, 0].denom()
    nash_q_values = [nash0, nash1]
    return nash_q_values


def update_leader_agents_NE_payoff_table(NE_payoff_table_dic,
                                         agents_current_states_dic,
                                         agents_actions_dic,
                                         agents_dic):
    state_list = []
    action_list = []
    q_table_list = []
    NE_values_list = []
    payoff_table_list = []
    NE_agents_current_states_dic = {}
    NE_agents_action_dic = {}
    q_table_dic = {}
    for key, val in NE_payoff_table_dic.items():
        payoff_table_list.append(NE_payoff_table_dic[key])
        NE_agents_current_states_dic[key] = agents_current_states_dic[key]
        NE_agents_action_dic[key] = agents_actions_dic[key]
        q_table_dic[key] = agents_dic[key].Asy_Ne_q_learning.Asy_Ne_ql_q_table
    for key, val in agents_current_states_dic.items():
        state_list.append(agents_current_states_dic[key])
    for key, val in NE_agents_action_dic.items():
        action_list.append(NE_agents_action_dic[key])
    for key, val in q_table_dic.items():
        q_table_list.append(q_table_dic[key])
    for i in range(0, 2):
        NE_values_list.append(q_table_list[i].loc[state_list[i], action_list[i]])

    if payoff_table_list[0].loc[action_list[0], action_list[1]] < NE_values_list[0]:
        payoff_table_list[0].loc[action_list[0], action_list[1]] = NE_values_list[0]
    if payoff_table_list[1].loc[action_list[0], action_list[1]] < NE_values_list[1]:
        payoff_table_list[1].loc[action_list[0], action_list[1]] = NE_values_list[1]
    """renew the payoff table dic"""
    i = 0
    for key, val in NE_payoff_table_dic.items():
        NE_payoff_table_dic[key] = payoff_table_list[i]
        i += 1
    return NE_payoff_table_dic

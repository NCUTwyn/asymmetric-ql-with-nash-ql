import pandas as pd


def initialize_Asy_payoff_table(agents_setting):
    """initialize_asymmetric_payoff_table
       table such as:
           A1 A2 A3 A4 A5
       A'1
       A'2
       A'3   Q(s,A1,A'3)
       A'4
       A'5
       need every agent's action name and length from settings
    """
    """Because of dataframe element format is difficult
       separate the payoff table from one to two
        leader A1 A2 A3 A4 A5            follower  A1 A2 A3 A4 A5
         A'1                               A'1
         A'2                               A'2
         A'3    Q(s,A,A')      and         A'3      Q'(s,A,A')
         A'4                               A'4
         A'5                               A'5
    """
    Asy_payoff_table_dic = {}
    for key, val in agents_setting.items():
        if agents_setting[key]['identity'] == 'Leader':
            Asy_payoff_table_dic[key] = {}
            for opponent in agents_setting[key]['asymmetric_opponent']:
                loc = agents_setting[key]['action']['names']
                col = agents_setting[opponent]['action']['names']
                Asy_payoff_table_dic[key][opponent] = pd.DataFrame(0.0, index=loc, columns=col)
                Asy_payoff_table_dic[opponent] = pd.DataFrame(0.0, index=loc, columns=col)
        else:
            pass
            # loc = agents_setting[key]['asymmetric_opponent']['action']['names']
            # col = agents_setting[key]['action']['names']
            # Asy_payoff_table_dic[key] = pd.DataFrame(0.0, index=loc, columns=col)
    return Asy_payoff_table_dic


def get_agents_SE_value_by(agents_dic, agents_setting, Asy_payoff_table_dic, agents_actions_dic):
    """
        every cell(list like [A1,A1']) in each row
        compare every cell's second number which belong follower agent and then pick max one
        compare their first number which belong leader agent and finally pick the max one
    """
    """
        get the max cell under each leader's action loc ————location
        In the follower payoff table
    """
    """
        注意：Dataframe的索引
        使用loc则['1', '2']为先横再竖
        使用table['1']['2']为先竖后横
    """
    SE_value_dic = {}
    for key, val in agents_dic.items():
        if agents_setting[key]['identity'] == 'Leader':
            SE_value_leader_dic = {}
            leader_action_list = agents_setting[key]['action']['names']
            for follower, follower_SE_payoff_table in Asy_payoff_table_dic[key].items():
                leader_payoff_table = Asy_payoff_table_dic[key][follower]
                follower_payoff_table = Asy_payoff_table_dic[follower]

                argmax_follower_location_list = []
                argmax_follower_value_list = []

                leader_action = agents_actions_dic[key]
                argmax_follower_value = 0
                argmax_follower_location = []
                for follower_action in agents_setting[follower]['action']['names']:
                    if follower_payoff_table.loc[leader_action, follower_action] >= argmax_follower_value:
                        argmax_follower_value = follower_payoff_table.loc[leader_action, follower_action]
                        argmax_follower_location = [leader_action, follower_action]
                    else:
                        pass
                argmax_leader_value = leader_payoff_table.loc[argmax_follower_location[0], argmax_follower_location[1]]
                SE_value_leader_dic[follower] = argmax_leader_value
                SE_value_dic[follower] = argmax_follower_value
            SE_value_dic[key] = SE_value_leader_dic
        else:
            pass
    return SE_value_dic


def update_agents_SE_payoff_table(Asy_payoff_table_dic, agents_dic, agents_setting,
                                  agents_current_states_dic, agents_actions_dic):
    for key, val in agents_setting.items():
        if agents_setting[key]['identity'] == 'Leader':
            for opponent in agents_setting[key]['asymmetric_opponent']:
                """SE_agent_list = [key, opponent]"""
                state_list = [agents_current_states_dic[key], agents_current_states_dic[opponent]]
                action_list = [agents_actions_dic[key], agents_actions_dic[opponent]]
                q_table_list = [agents_dic[key].Asy_Ne_q_learning.Asy_Ne_ql_q_table, agents_dic[opponent].Asy_Ne_q_learning.Asy_Ne_ql_q_table]
                SE_values_list = [q_table_list[0].loc[state_list[0], action_list[0]], q_table_list[1].loc[state_list[1], action_list[1]]]
                if Asy_payoff_table_dic[key][opponent].loc[action_list[0], action_list[1]] < SE_values_list[0]:
                    Asy_payoff_table_dic[key][opponent].loc[action_list[0], action_list[1]] = SE_values_list[0]
                if Asy_payoff_table_dic[opponent].loc[action_list[0], action_list[1]] < SE_values_list[1]:
                    Asy_payoff_table_dic[opponent].loc[action_list[0], action_list[1]] = SE_values_list[1]
        else:
            pass
    return Asy_payoff_table_dic

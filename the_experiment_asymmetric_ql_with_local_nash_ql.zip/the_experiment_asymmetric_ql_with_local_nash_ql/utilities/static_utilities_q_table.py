import Asy_NE_agent


def update_agents_q_tables(pre_state, actions, rewards, leader_agents_NE_value_dic,
                           agents_SE_values_dic, agents_setting, agents_dic):
    for key, val in agents_dic.items():
        if agents_setting[key]['identity'] == 'Leader':
            """Leader's Q value in Q table won't be influenced by the SE"""
            leader_agent_NE_value = leader_agents_NE_value_dic[key]
            game_theory_value = leader_agent_NE_value
            val.update_q_table_ql_single(pre_state=pre_state[key],
                                         action=actions[key],
                                         reward=rewards[key],
                                         game_theory_value=game_theory_value)
        else:
            agent_SE_value = agents_SE_values_dic[key]
            game_theory_value = agent_SE_value
            val.update_q_table_ql_single(pre_state=pre_state[key],
                                         action=actions[key],
                                         reward=rewards[key],
                                         game_theory_value=game_theory_value)


def q_table_q_value(**kwargs):
    """ update q table with state,action,q"""
    alpha = kwargs['alpha']
    gamma = kwargs['gamma']
    reward = kwargs['reward']
    pre_q = kwargs['pre_q']
    game_theory_value = kwargs['game_theory_value']
    q_new = (1 - alpha) * pre_q + alpha * (reward + gamma * game_theory_value)
    return q_new

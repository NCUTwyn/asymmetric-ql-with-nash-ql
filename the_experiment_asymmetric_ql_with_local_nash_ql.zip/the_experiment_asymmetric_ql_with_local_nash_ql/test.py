# dic = {'A': 1, 'B': 2}
# for key, val in dic.items():
#     print('key:', key)
#     print('val', val)

import pandas as pd

"""
    注意：Dataframe的索引
    使用loc则['1', '2']为先横再竖
    使用table['1']['2']为先竖后横
"""
loc = ['A', 'B', 'C', 'D']
col = ['X', 'Y', 'Z']
table = pd.DataFrame(0.0, index=loc, columns=col)
print(table)
print(table.loc['A', 'X'])
print(table['X']['A'])


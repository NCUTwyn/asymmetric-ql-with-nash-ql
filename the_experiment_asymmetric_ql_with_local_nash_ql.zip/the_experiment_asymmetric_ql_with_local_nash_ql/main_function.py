"""
Asymmetric with local Nash Equilibrium Q Learning
"""
from utilities.static_utilities import *
from utilities.Nash_Equilibrium import *
from utilities.Stackelberg_Equilibrium import *
from utilities.static_utilities_states import *
from utilities.static_utilities_actions import *
from utilities.static_utilities_rewards import *
from utilities.static_utilities_q_table import *
from traffic_environment import TrafficEnvironment
import traci

"""get setting from yaml file"""
environment_setting, agents_setting, constants_setting = get_settings_from_yaml('the_second_3.yaml')
"""initialize agents"""
agents_dic = initialize_agents_by(agents_setting=agents_setting)
"""initialize Nash Q Learning's payoff table for two leaders in system """
NE_payoff_table_dic, loc, col, NE_agents_list = initialize_NE_payoff_table(agents_setting=agents_setting)
"""initialize asymmetric payoff table for every agents"""
Asy_payoff_table_dic = initialize_Asy_payoff_table(agents_setting=agents_setting)
"""compute episode"""
episode = 0
while episode < constants_setting['episodes']:
    """load SUMO as encironment"""
    traffic_environment = TrafficEnvironment(environment_setting=environment_setting)
    """episode+1"""
    episode += 1
    """begin simulation"""
    step = 0
    traffic_environment.pre_run_simulation_to_prepare(pre_steps=environment_setting['pre_steps'])
    """get current state"""
    agents_states_t_dic = get_agents_states_by(environment=traffic_environment, agents_dic=agents_dic)
    """traffic signal control"""
    while step < environment_setting['simulation_time']:
        """observe current states of all agents"""
        agents_current_states_dic = agents_states_t_dic
        """action selection for each agent"""
        agents_actions_dic = get_agents_actions_by(agents_dic=agents_dic, agents_states=agents_current_states_dic)
        """
        if reward is sum_chang_of_queue_on_each_edge from last step
        obtain reward para before executing action
        """
        agents_rewards_before = get_agents_rewards_by(environment=traffic_environment, agents_dic=agents_dic)
        """execute action"""
        execute_actions_in_environment(environment=traffic_environment, agents_dic=agents_dic, actions_dic=agents_actions_dic)
        """keep a few steps in simulation after execute action to make sure the effect obviously"""
        simulate_step = 0
        while simulate_step < constants_setting['simulate_step_after_each_action_selection']:
            step += 1
            simulate_step += 1
            traffic_environment.simulation_step()
        """observe new states"""
        agents_new_states_dic = get_agents_states_by(environment=traffic_environment, agents_dic=agents_dic)
        agents_states_t_dic = agents_new_states_dic
        """obtain reward para after executing action and simulating"""
        agents_rewards_after = get_agents_rewards_by(environment=traffic_environment, agents_dic=agents_dic)
        agents_rewards = calculate_rewards_about_change_queue(reward_before=agents_rewards_before,
                                                              reward_after=agents_rewards_after)
        """calculate nash q value of two leader"""
        leader_agents_NE_value_dic = get_leaders_NE_values_by(NE_agents_list=NE_agents_list,
                                                              NE_payoff_table_dic=NE_payoff_table_dic,
                                                              loc=loc, col=col)
        """calculate Stackelberg equilibrium value"""
        agents_SE_values_dic = get_agents_SE_value_by(agents_dic=agents_dic, agents_setting=agents_setting,
                                                      Asy_payoff_table_dic=Asy_payoff_table_dic,
                                                      agents_actions_dic=agents_actions_dic)
        """update Q table"""
        update_agents_q_tables(pre_state=agents_current_states_dic, actions=agents_actions_dic, rewards=agents_rewards,
                               leader_agents_NE_value_dic=leader_agents_NE_value_dic,
                               agents_SE_values_dic=agents_SE_values_dic,
                               agents_setting=agents_setting, agents_dic=agents_dic)
        """update nash equilibrium payoff table"""
        update_leader_agents_NE_payoff_table(NE_payoff_table_dic=NE_payoff_table_dic,
                                             agents_current_states_dic=agents_current_states_dic,
                                             agents_actions_dic=agents_actions_dic,
                                             agents_dic=agents_dic)
        """update Stackelberg equilibrium payoff table"""
        update_agents_SE_payoff_table(Asy_payoff_table_dic=Asy_payoff_table_dic,
                                      agents_dic=agents_dic,
                                      agents_setting=agents_setting,
                                      agents_current_states_dic=agents_current_states_dic,
                                      agents_actions_dic=agents_actions_dic)
    traci.close()

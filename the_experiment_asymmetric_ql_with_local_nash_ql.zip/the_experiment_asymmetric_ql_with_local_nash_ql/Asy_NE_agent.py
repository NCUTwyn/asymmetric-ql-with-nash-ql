from Asy_Ne_Q_Learning import *


class AsyNeQlAgent:
    def __init__(self, agents_setting):
        """Initialization AsymmetricQlAgent"""
        print('Asy_Ne_Ql_Agent初始化……')
        self.agent_id = agents_setting['cross_id']
        self.tls_id = agents_setting['tls_id']  # 信号灯id
        self.state_config = agents_setting['states']  # basic info about states of the agent
        self.action_config = agents_setting['action']  # action config
        self.reward_config = agents_setting['rewards']  # reward config
        Asy_Ne_q_learning_setting = agents_setting['asymmetric_q_learning_settings']  # nash_ql模型
        self.Asy_Ne_q_learning = AsyNeQLearning(Asy_Ne_q_learning_setting=Asy_Ne_q_learning_setting,
                                                state_names_list=self.state_config['names'],
                                                action_names_list=self.action_config['names'])

    def get_state_config(self):
        """返回“状态”相关信息"""
        return self.state_config

    def get_action_config(self):
        """返回“动作”相关信息"""
        return self.action_config

    def get_reward_config(self):
        """返回“奖励”相关信息"""
        return self.reward_config

    def get_tls_id(self):
        """返回信号灯ID"""
        return self.tls_id

    def get_q_value_by(self, state, action):
        return self.Asy_Ne_q_learning.get_q_value_by(state, action)

    def get_action_selection_model(self):
        """获取动作选择模型"""
        return self.Asy_Ne_q_learning.get_action_selection_model()

    def select_action_eps_greedy(self, state):
        """action selection"""
        return self.Asy_Ne_q_learning.select_action_eps_greedy(state=state)

    def update_q_table_ql_single(self, pre_state, action, reward, game_theory_value):
        """更新Q表，只考虑本地信息"""
        self.Asy_Ne_q_learning.update_Asy_NE_q_learning_table(current_state=pre_state,
                                                              action=action,
                                                              reward=reward,
                                                              game_theory_value=game_theory_value)
